/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          950: '#05050f',
          900: '#0a0a18',
          800: '#101028',
          700: '#161636',
        },
        brand: {
          indigo: '#6366f1',
          cyan: '#22d3ee',
          violet: '#a855f7',
        },
      },
      fontFamily: {
        display: ['Sora', 'Inter', 'sans-serif'],
        body: ['Inter', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        glow: '0 0 30px rgba(99,102,241,0.45)',
      },
    },
  },
  plugins: [],
};
