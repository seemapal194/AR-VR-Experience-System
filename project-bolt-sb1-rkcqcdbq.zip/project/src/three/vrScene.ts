import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { VRButton } from 'three/examples/jsm/webxr/VRButton.js';
import { cloneObjectById, OBJECT_CATALOG } from './objects';

export interface VRHandles {
  dispose: () => void;
  enterVR: () => Promise<void>;
  resetView: () => void;
}

interface CreateVROpts {
  canvas: HTMLCanvasElement;
  container: HTMLElement;
  vrButtonHost: HTMLElement;
  onVRStateChange: (active: boolean) => void;
  onError?: (m: string) => void;
}

export function createVRScene(opts: CreateVROpts): VRHandles {
  const { canvas, container, vrButtonHost, onVRStateChange, onError } = opts;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x06061a);
  scene.fog = new THREE.Fog(0x06061a, 18, 45);

  const camera = new THREE.PerspectiveCamera(60, 1, 0.1, 200);
  camera.position.set(0, 1.7, 9);

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.xr.enabled = true;

  // Lights
  scene.add(new THREE.AmbientLight(0x9bb0ff, 0.45));
  const sun = new THREE.DirectionalLight(0xffffff, 1.1);
  sun.position.set(8, 12, 6);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.left = -15;
  sun.shadow.camera.right = 15;
  sun.shadow.camera.top = 15;
  sun.shadow.camera.bottom = -15;
  scene.add(sun);
  const p1 = new THREE.PointLight(0x6366f1, 0.9, 30);
  p1.position.set(-6, 4, -6);
  scene.add(p1);
  const p2 = new THREE.PointLight(0x22d3ee, 0.9, 30);
  p2.position.set(6, 4, 6);
  scene.add(p2);

  // Floor
  const floorMat = new THREE.MeshStandardMaterial({
    color: 0x12122a,
    metalness: 0.4,
    roughness: 0.6,
  });
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(40, 40), floorMat);
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);

  const grid = new THREE.GridHelper(40, 40, 0x4338ca, 0x1e293b);
  (grid.material as THREE.Material).opacity = 0.35;
  (grid.material as THREE.Material).transparent = true;
  scene.add(grid);

  // Build a virtual exhibition room (walls)
  const wallMat = new THREE.MeshStandardMaterial({
    color: 0x0e0e24,
    metalness: 0.2,
    roughness: 0.85,
    side: THREE.DoubleSide,
  });
  const wallHeight = 5;
  const roomSize = 18;
  const walls: [number, number, number, number, number][] = [
    // x, z, width, depth, rotY
    [0, -roomSize / 2, roomSize, 0.3, 0], // back
    [-roomSize / 2, 0, 0.3, roomSize, 0], // left
    [roomSize / 2, 0, 0.3, roomSize, 0], // right
  ];
  walls.forEach(([x, z, w, d]) => {
    const wall = new THREE.Mesh(new THREE.BoxGeometry(w, wallHeight, d), wallMat);
    wall.position.set(x, wallHeight / 2, z);
    wall.receiveShadow = true;
    wall.castShadow = true;
    scene.add(wall);
  });

  // Ceiling emissive strips
  for (let i = -2; i <= 2; i++) {
    const strip = new THREE.Mesh(
      new THREE.BoxGeometry(0.2, 0.05, roomSize - 1),
      new THREE.MeshStandardMaterial({
        color: 0x67e8f9,
        emissive: 0x22d3ee,
        emissiveIntensity: 1.4,
      }),
    );
    strip.position.set(i * 3, wallHeight - 0.1, 0);
    scene.add(strip);
  }

  // Pedestals with objects
  const pedestalMat = new THREE.MeshStandardMaterial({
    color: 0x1a1a3a,
    metalness: 0.5,
    roughness: 0.4,
  });
  const placement: { id: string; x: number; z: number }[] = [
    { id: 'crystal', x: -5, z: -3 },
    { id: 'chair', x: -2.5, z: -5 },
    { id: 'table', x: 2.5, z: -5 },
    { id: 'lamp', x: 5, z: -3 },
    { id: 'torus', x: -5, z: 3 },
    { id: 'sphere', x: 0, z: 4 },
    { id: 'cube', x: 5, z: 3 },
    { id: 'cone', x: 0, z: -6.5 },
  ];

  placement.forEach(({ id, x, z }) => {
    const info = OBJECT_CATALOG.find((o) => o.id === id);
    if (!info) return;
    const ped = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.8, 1.4), pedestalMat);
    ped.position.set(x, 0.4, z);
    ped.castShadow = true;
    ped.receiveShadow = true;
    scene.add(ped);

    const obj = cloneObjectById(id);
    obj.position.set(x, 1.6, z);
    obj.scale.setScalar(0.9);
    obj.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) {
        (o as THREE.Mesh).castShadow = true;
      }
    });
    obj.userData.spinning = true;
    scene.add(obj);

    // accent point light on pedestal
    const pl = new THREE.PointLight(info.accent, 0.6, 5);
    pl.position.set(x, 2.2, z);
    scene.add(pl);
  });

  // Decorative orbiting spheres
  const orbiters: THREE.Mesh[] = [];
  for (let i = 0; i < 14; i++) {
    const m = new THREE.Mesh(
      new THREE.SphereGeometry(0.08, 12, 12),
      new THREE.MeshStandardMaterial({
        color: 0xa5b4fc,
        emissive: 0x6366f1,
        emissiveIntensity: 0.8,
      }),
    );
    const r = 7 + Math.random() * 2;
    const a = (i / 14) * Math.PI * 2;
    m.position.set(Math.cos(a) * r, 2 + Math.random() * 2, Math.sin(a) * r);
    scene.add(m);
    orbiters.push(m);
  }

  // OrbitControls (desktop navigation)
  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.target.set(0, 1.5, 0);
  controls.minDistance = 3;
  controls.maxDistance = 20;
  controls.maxPolarAngle = Math.PI * 0.55;

  // Keyboard navigation (WASD)
  const keys: Record<string, boolean> = {};
  const onKeyDown = (e: KeyboardEvent) => {
    keys[e.key.toLowerCase()] = true;
  };
  const onKeyUp = (e: KeyboardEvent) => {
    keys[e.key.toLowerCase()] = false;
  };
  window.addEventListener('keydown', onKeyDown);
  window.addEventListener('keyup', onKeyUp);

  const moveSpeed = 5; // units/sec
  const tmpForward = new THREE.Vector3();
  const tmpRight = new THREE.Vector3();
  function applyKeyboard(dt: number) {
    if (renderer.xr.isPresenting) return; // headset uses its own locomotion
    const f = (keys['w'] ? 1 : 0) - (keys['s'] ? 1 : 0);
    const r = (keys['d'] ? 1 : 0) - (keys['a'] ? 1 : 0);
    if (f === 0 && r === 0) return;
    camera.getWorldDirection(tmpForward);
    tmpForward.y = 0;
    tmpForward.normalize();
    tmpRight.crossVectors(tmpForward, camera.up).normalize();
    const step = moveSpeed * dt;
    camera.position.addScaledVector(tmpForward, f * step);
    camera.position.addScaledVector(tmpRight, r * step);
    // clamp inside room
    camera.position.x = THREE.MathUtils.clamp(camera.position.x, -8, 8);
    camera.position.z = THREE.MathUtils.clamp(camera.position.z, -8, 8);
    camera.position.y = 1.7;
    controls.target.copy(camera.position).add(tmpForward);
  }

  // VR Button
  let vrButtonEl: HTMLElement | null = null;
  try {
    vrButtonEl = VRButton.createButton(renderer);
    vrButtonHost.appendChild(vrButtonEl);
  } catch {
    // VRButton may throw if WebXR unavailable; we handle via xr session check separately
  }

  let vrActive = false;
  renderer.xr.addEventListener('sessionstart', () => {
    vrActive = true;
    onVRStateChange(true);
  });
  renderer.xr.addEventListener('sessionend', () => {
    vrActive = false;
    onVRStateChange(false);
  });

  // Resize
  function setSize() {
    const w = container.clientWidth || 800;
    const h = container.clientHeight || 500;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  const ro = new ResizeObserver(setSize);
  ro.observe(container);
  setSize();

  const clock = new THREE.Clock();
  const tempY = new THREE.Vector3();
  renderer.setAnimationLoop(() => {
    const dt = clock.getDelta();
    const t = clock.elapsedTime;
    // spin objects on pedestals
    scene.children.forEach((c) => {
      if (c.userData?.spinning && (c as THREE.Group).type === 'Group') {
        c.rotation.y += 0.4 * dt;
      }
    });
    // orbiters
    orbiters.forEach((m, i) => {
      const a = t * 0.3 + (i / orbiters.length) * Math.PI * 2;
      const r = 7 + Math.sin(t + i) * 0.6;
      m.position.set(Math.cos(a) * r, 2 + Math.sin(t * 0.8 + i) * 0.8, Math.sin(a) * r);
    });
    applyKeyboard(dt);
    controls.update();
    if (!renderer.xr.isPresenting) renderer.render(scene, camera);
  });
  void tempY;

  function dispose() {
    renderer.setAnimationLoop(null);
    ro.disconnect();
    window.removeEventListener('keydown', onKeyDown);
    window.removeEventListener('keyup', onKeyUp);
    controls.dispose();
    if (vrButtonEl && vrButtonEl.parentElement) vrButtonEl.parentElement.removeChild(vrButtonEl);
    renderer.dispose();
    scene.traverse((o) => {
      if ((o as THREE.Mesh).geometry) (o as THREE.Mesh).geometry.dispose();
      const m = (o as THREE.Mesh).material;
      if (Array.isArray(m)) m.forEach((mm) => mm.dispose());
      else if (m) (m as THREE.Material).dispose();
    });
  }

  async function enterVR() {
    try {
      if (!('xr' in navigator)) {
        onError?.('WebXR not available in this browser.');
        return;
      }
      const xr = (navigator as Navigator & { xr: XRSystem }).xr;
      const supported = await xr.isSessionSupported('immersive-vr');
      if (!supported) {
        onError?.('No immersive-VR device detected. Use desktop navigation to explore the room.');
        return;
      }
      const session = await xr.requestSession('immersive-vr', {
        optionalFeatures: ['local-floor', 'bounded-floor', 'hand-tracking'],
      });
      await renderer.xr.setSession(session);
    } catch (e) {
      onError?.('Could not start VR session: ' + (e as Error).message);
    }
  }

  function resetView() {
    camera.position.set(0, 1.7, 9);
    controls.target.set(0, 1.5, 0);
    controls.update();
  }

  return { dispose, enterVR, resetView };
}
