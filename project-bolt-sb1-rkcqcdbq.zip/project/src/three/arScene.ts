import * as THREE from 'three';

export interface ARHandles {
  dispose: () => void;
  startCamera: () => Promise<void>;
  stopCamera: () => void;
  placeObject: (id: string) => void;
  rotate: (dx: number, dy: number) => void;
  setScale: (v: number) => void;
  move: (x: number, y: number) => void;
  resetObject: () => void;
  cameraActive: () => boolean;
}

interface CreateAROpts {
  video: HTMLVideoElement;
  canvas: HTMLCanvasElement;
  container: HTMLElement;
  onStatus: (s: string) => void;
  onError: (m: string) => void;
}

export function createARScene(opts: CreateAROpts): ARHandles {
  const { video, canvas, container, onStatus, onError } = opts;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(60, 1, 0.1, 1000);
  camera.position.set(0, 0, 0);

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.shadowMap.enabled = true;

  // Lights — match real-world approx
  scene.add(new THREE.AmbientLight(0xffffff, 0.9));
  const dir = new THREE.DirectionalLight(0xffffff, 0.8);
  dir.position.set(2, 5, 4);
  scene.add(dir);

  let current: THREE.Group | null = null;
  let baseScale = 1;
  const objPos = new THREE.Vector3(0, 0, -3);
  const objRot = new THREE.Euler();
  let userScale = 1;
  let mediaStream: MediaStream | null = null;
  let cameraOn = false;
  let disposed = false;

  function setSize() {
    const w = container.clientWidth || 600;
    const h = container.clientHeight || 450;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  const ro = new ResizeObserver(setSize);
  ro.observe(container);
  setSize();

  function placeObject(id: string, builder: (id: string) => THREE.Group) {
    if (current) {
      scene.remove(current);
      current.traverse((o) => {
        if ((o as THREE.Mesh).geometry) (o as THREE.Mesh).geometry.dispose();
        const m = (o as THREE.Mesh).material;
        if (Array.isArray(m)) m.forEach((mm) => mm.dispose());
        else if (m) (m as THREE.Material).dispose();
      });
    }
    const g = builder(id);
    g.position.copy(objPos);
    g.rotation.copy(objRot);
    g.scale.setScalar(userScale);
    g.traverse((o) => {
      if ((o as THREE.Mesh).isMesh) {
        (o as THREE.Mesh).castShadow = true;
        (o as THREE.Mesh).receiveShadow = true;
      }
    });
    scene.add(g);
    current = g;
  }

  function rotate(dx: number, dy: number) {
    objRot.y += dx;
    objRot.x += dy;
    if (current) current.rotation.copy(objRot);
  }

  function setScale(v: number) {
    userScale = v;
    if (current) current.scale.setScalar(v);
  }

  function move(x: number, y: number) {
    objPos.x = THREE.MathUtils.clamp(objPos.x + x, -4, 4);
    objPos.y = THREE.MathUtils.clamp(objPos.y + y, -3, 3);
    if (current) current.position.copy(objPos);
  }

  function resetObject() {
    objPos.set(0, 0, -3);
    objRot.set(0, 0, 0);
    userScale = 1;
    if (current) {
      current.position.copy(objPos);
      current.rotation.copy(objRot);
      current.scale.setScalar(1);
    }
  }

  async function startCamera() {
    if (cameraOn) return;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      onError('Camera API (MediaDevices) is not available in this browser. Try HTTPS or a modern browser.');
      onStatus('unsupported');
      return;
    }
    onStatus('requesting');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      mediaStream = stream;
      video.srcObject = stream;
      await video.play();
      cameraOn = true;
      onStatus('active');
    } catch (e) {
      const err = e as DOMException;
      if (err.name === 'NotAllowedError') {
        onError('Camera permission was denied. Please allow camera access and try again.');
      } else if (err.name === 'NotFoundError') {
        onError('No camera device was found on this machine.');
      } else {
        onError('Could not access the camera: ' + err.message);
      }
      onStatus('denied');
    }
  }

  function stopCamera() {
    if (mediaStream) {
      mediaStream.getTracks().forEach((t) => t.stop());
      mediaStream = null;
    }
    video.srcObject = null;
    cameraOn = false;
    onStatus('idle');
  }

  // pointer drag for rotate
  let dragging = false;
  let lastX = 0;
  let lastY = 0;
  function onDown(e: PointerEvent) {
    dragging = true;
    lastX = e.clientX;
    lastY = e.clientY;
  }
  function onMove(e: PointerEvent) {
    if (!dragging) return;
    const dx = (e.clientX - lastX) * 0.01;
    const dy = (e.clientY - lastY) * 0.01;
    lastX = e.clientX;
    lastY = e.clientY;
    rotate(dx, dy);
  }
  function onUp() {
    dragging = false;
  }
  canvas.addEventListener('pointerdown', onDown);
  window.addEventListener('pointermove', onMove);
  window.addEventListener('pointerup', onUp);

  // pinch to scale (two-pointer)
  const activePointers = new Map<number, { x: number; y: number }>();
  let initialPinchDist = 0;
  let initialScale = 1;
  function onPointerDownPinch(e: PointerEvent) {
    activePointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (activePointers.size === 2) {
      const pts = Array.from(activePointers.values());
      initialPinchDist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
      initialScale = userScale;
    }
  }
  function onPointerMovePinch(e: PointerEvent) {
    if (!activePointers.has(e.pointerId)) return;
    activePointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (activePointers.size === 2) {
      const pts = Array.from(activePointers.values());
      const d = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
      if (initialPinchDist > 0) {
        const ratio = d / initialPinchDist;
        setScale(THREE.MathUtils.clamp(initialScale * ratio, 0.2, 5));
      }
    }
  }
  function onPointerUpPinch(e: PointerEvent) {
    activePointers.delete(e.pointerId);
    if (activePointers.size < 2) initialPinchDist = 0;
  }
  canvas.addEventListener('pointerdown', onPointerDownPinch);
  canvas.addEventListener('pointermove', onPointerMovePinch);
  canvas.addEventListener('pointerup', onPointerUpPinch);
  canvas.addEventListener('pointercancel', onPointerUpPinch);

  // render loop
  renderer.setAnimationLoop(() => {
    if (disposed) return;
    // keep camera aspect tied to video size when active
    if (cameraOn && video.videoWidth) {
      const w = container.clientWidth;
      const h = container.clientHeight;
      const vAspect = video.videoWidth / video.videoHeight;
      const cAspect = w / h;
      // crop-style: use container aspect; video is object-cover in CSS
      camera.aspect = cAspect || vAspect;
      camera.updateProjectionMatrix();
    }
    renderer.render(scene, camera);
  });

  function dispose() {
    disposed = true;
    renderer.setAnimationLoop(null);
    ro.disconnect();
    canvas.removeEventListener('pointerdown', onDown);
    window.removeEventListener('pointermove', onMove);
    window.removeEventListener('pointerup', onUp);
    canvas.removeEventListener('pointerdown', onPointerDownPinch);
    canvas.removeEventListener('pointermove', onPointerMovePinch);
    canvas.removeEventListener('pointerup', onPointerUpPinch);
    canvas.removeEventListener('pointercancel', onPointerUpPinch);
    stopCamera();
    renderer.dispose();
  }

  void baseScale;

  return {
    dispose,
    startCamera,
    stopCamera,
    placeObject: (id) => placeObject(id, (i) => {
      // lazy import to avoid circular deps
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const mod = (window as any).__AR_OBJ_BUILDER__ as ((id: string) => THREE.Group) | undefined;
      if (mod) return mod(id);
      return new THREE.Group();
    }),
    rotate,
    setScale,
    move,
    resetObject,
    cameraActive: () => cameraOn,
  };
}
