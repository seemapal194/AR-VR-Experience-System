import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

export interface ExplorerHandles {
  dispose: () => void;
  resetObject: () => void;
  setScale: (v: number) => void;
  setRotationSpeed: (v: number) => void;
  toggleAutoRotate: (v: boolean) => void;
  focusObject: (id: string) => void;
}

interface CreateExplorerOpts {
  canvas: HTMLCanvasElement;
  container: HTMLElement;
  onSelect: (id: string | null) => void;
  onError?: (msg: string) => void;
}

export function createObjectExplorer(opts: CreateExplorerOpts): ExplorerHandles {
  const { canvas, container, onSelect, onError } = opts;

  const scene = new THREE.Scene();
  scene.background = null;

  const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 100);
  camera.position.set(3.5, 2.5, 5);

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  // Lights
  scene.add(new THREE.AmbientLight(0xffffff, 0.55));
  const key = new THREE.DirectionalLight(0xffffff, 1.2);
  key.position.set(5, 8, 6);
  key.castShadow = true;
  key.shadow.mapSize.set(1024, 1024);
  key.shadow.camera.near = 0.5;
  key.shadow.camera.far = 30;
  scene.add(key);
  const fill = new THREE.PointLight(0x6366f1, 0.7, 30);
  fill.position.set(-4, 3, -3);
  scene.add(fill);
  const rim = new THREE.PointLight(0x22d3ee, 0.6, 25);
  rim.position.set(3, 2, -5);
  scene.add(rim);

  // Ground plane (subtle)
  const ground = new THREE.Mesh(
    new THREE.CircleGeometry(8, 64),
    new THREE.MeshStandardMaterial({
      color: 0x0b0b1f,
      metalness: 0.2,
      roughness: 0.85,
      transparent: true,
      opacity: 0.6,
    }),
  );
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -1.1;
  ground.receiveShadow = true;
  scene.add(ground);

  const grid = new THREE.GridHelper(12, 24, 0x4f46e5, 0x1e293b);
  (grid.material as THREE.Material).opacity = 0.25;
  (grid.material as THREE.Material).transparent = true;
  grid.position.y = -1.09;
  scene.add(grid);

  const controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dampingFactor = 0.08;
  controls.minDistance = 2;
  controls.maxDistance = 12;
  controls.maxPolarAngle = Math.PI * 0.95;

  // Object registry imported lazily to avoid circular import problems
  // We import the catalog via a callback injected by caller — but simpler: dynamic import
  let disposed = false;
  let current: THREE.Group | null = null;
  let autoRotate = true;
  let rotationSpeed = 0.6;
  let userScale = 1;
  const baseScale = 1;
  let baseTransform = { pos: new THREE.Vector3(), rot: new THREE.Euler(), scale: 1 };

  const raycaster = new THREE.Raycaster();
  const pointer = new THREE.Vector2();

  function setSize() {
    const w = container.clientWidth || 600;
    const h = container.clientHeight || 400;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }

  const ro = new ResizeObserver(setSize);
  ro.observe(container);
  setSize();

  function setObject(group: THREE.Group) {
    if (current) {
      scene.remove(current);
      current.traverse((o) => {
        if ((o as THREE.Mesh).geometry) (o as THREE.Mesh).geometry.dispose();
        const m = (o as THREE.Mesh).material;
        if (Array.isArray(m)) m.forEach((mm) => mm.dispose());
        else if (m) (m as THREE.Material).dispose();
      });
    }
    current = group;
    group.position.set(0, 0, 0);
    group.rotation.set(0, 0, 0);
    group.scale.setScalar(baseScale * userScale);
    scene.add(group);
    baseTransform = {
      pos: group.position.clone(),
      rot: group.rotation.clone(),
      scale: baseScale,
    };
  }

  // Public: load object by id through injected builder
  function loadById(id: string, builder: (id: string) => THREE.Group) {
    const g = builder(id);
    setObject(g);
  }

  function resetObject() {
    if (!current) return;
    current.position.copy(baseTransform.pos);
    current.rotation.copy(baseTransform.rot);
    userScale = 1;
    current.scale.setScalar(baseScale);
  }

  function setScale(v: number) {
    userScale = v;
    if (current) current.scale.setScalar(baseScale * v);
  }

  function setRotationSpeed(v: number) {
    rotationSpeed = v;
  }

  function toggleAutoRotate(v: boolean) {
    autoRotate = v;
  }

  function focusObject(id: string) {
    onSelect(id);
  }

  // Click selection (raycast)
  function onPointerDown(ev: PointerEvent) {
    const rect = renderer.domElement.getBoundingClientRect();
    pointer.x = ((ev.clientX - rect.left) / rect.width) * 2 - 1;
    pointer.y = -((ev.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(pointer, camera);
    if (!current) return;
    const hits = raycaster.intersectObject(current, true);
    if (hits.length > 0) {
      const info = current.userData.info;
      if (info) onSelect(info.id);
    } else {
      onSelect(null);
    }
  }
  renderer.domElement.addEventListener('pointerdown', onPointerDown);

  const clock = new THREE.Clock();
  function animate() {
    if (disposed) return;
    const dt = clock.getDelta();
    if (current && autoRotate) {
      current.rotation.y += rotationSpeed * dt;
    }
    controls.update();
    renderer.render(scene, camera);
    requestAnimationFrame(animate);
  }
  animate();

  function dispose() {
    disposed = true;
    ro.disconnect();
    renderer.domElement.removeEventListener('pointerdown', onPointerDown);
    controls.dispose();
    renderer.dispose();
    scene.traverse((o) => {
      if ((o as THREE.Mesh).geometry) (o as THREE.Mesh).geometry.dispose();
      const m = (o as THREE.Mesh).material;
      if (Array.isArray(m)) m.forEach((mm) => mm.dispose());
      else if (m) (m as THREE.Material).dispose();
    });
  }

  function getErrorReporter() {
    return onError;
  }

  return {
    dispose,
    resetObject,
    setScale,
    setRotationSpeed,
    toggleAutoRotate,
    focusObject,
    loadById,
    _onError: getErrorReporter,
  } as ExplorerHandles & { loadById: (id: string, b: (id: string) => THREE.Group) => void; _onError: () => ((m: string) => void) | undefined };
}
