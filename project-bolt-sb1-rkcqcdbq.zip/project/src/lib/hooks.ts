import { useEffect, useRef, useState } from 'react';

export function useWebXRSupport() {
  const [vrSupported, setVrSupported] = useState<boolean | null>(null);
  const [arSupported, setArSupported] = useState<boolean | null>(null);

  useEffect(() => {
    if (typeof navigator === 'undefined' || !('xr' in navigator)) {
      setVrSupported(false);
      setArSupported(false);
      return;
    }
    const xr = (navigator as Navigator & { xr: XRSystem }).xr;
    xr.isSessionSupported('immersive-vr').then(setVrSupported).catch(() => setVrSupported(false));
    xr.isSessionSupported('immersive-ar').then(setArSupported).catch(() => setArSupported(false));
  }, []);

  return { vrSupported, arSupported };
}

export function useResizeObserver<T extends HTMLElement>() {
  const ref = useRef<T | null>(null);
  const [size, setSize] = useState({ width: 0, height: 0 });

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const ro = new ResizeObserver((entries) => {
      const r = entries[0].contentRect;
      setSize({ width: r.width, height: r.height });
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  return { ref, size };
}
