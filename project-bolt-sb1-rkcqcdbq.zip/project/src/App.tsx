import { useEffect, useState } from 'react';
import Navbar, { type ModuleId } from '@/components/Navbar';
import Home from '@/components/Home';
import ObjectExplorer from '@/components/ObjectExplorer';
import VRMode from '@/components/VRMode';
import ARMode from '@/components/ARMode';
import Compare from '@/components/Compare';
import Info from '@/components/Info';

function App() {
  const [active, setActive] = useState<ModuleId>('home');

  // Scroll to top on module change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [active]);

  return (
    <div className="min-h-screen">
      <div className="aurora-bg" />
      <Navbar active={active} onNavigate={setActive} />

      <main>
        {active === 'home' && <Home onNavigate={setActive} />}
        {active === 'explorer' && <ObjectExplorer />}
        {active === 'vr' && <VRMode />}
        {active === 'ar' && <ARMode />}
        {active === 'compare' && <Compare onNavigate={setActive} />}
        {active === 'info' && <Info onNavigate={setActive} />}
      </main>
    </div>
  );
}

export default App;
