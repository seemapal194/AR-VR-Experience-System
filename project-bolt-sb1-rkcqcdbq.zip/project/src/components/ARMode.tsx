import { useEffect, useRef, useState } from 'react';
import { CameraOff, Maximize2, Minimize2, Move, RotateCcw, ScanLine, Video, X } from 'lucide-react';
import { OBJECT_CATALOG, cloneObjectById } from '@/three/objects';
import { createARScene, type ARHandles } from '@/three/arScene';
import { useWebXRSupport } from '@/lib/hooks';

type Status = 'idle' | 'requesting' | 'active' | 'denied' | 'unsupported';

export default function ARMode() {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const handlesRef = useRef<ARHandles | null>(null);
  const { arSupported } = useWebXRSupport();

  const [status, setStatus] = useState<Status>('idle');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState<string>(OBJECT_CATALOG[0].id);
  const [scale, setScale] = useState(1);
  const [fullscreen, setFullscreen] = useState(false);

  // Provide object builder to the scene via window (avoids circular import)
  useEffect(() => {
    (window as any).__AR_OBJ_BUILDER__ = (id: string) => cloneObjectById(id);
    return () => {
      delete (window as any).__AR_OBJ_BUILDER__;
    };
  }, []);

  useEffect(() => {
    if (!containerRef.current || !canvasRef.current || !videoRef.current) return;
    let h: ARHandles | null = null;
    try {
      h = createARScene({
        video: videoRef.current,
        canvas: canvasRef.current,
        container: containerRef.current,
        onStatus: (s) => setStatus(s as Status),
        onError: (m) => setError(m),
      });
      handlesRef.current = h;
      setLoading(false);
    } catch (e) {
      setError('WebGL initialization failed: ' + (e as Error).message);
      setLoading(false);
    }
    return () => {
      h?.dispose();
      handlesRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (handlesRef.current) handlesRef.current.placeObject(selectedId);
  }, [selectedId]);

  useEffect(() => {
    handlesRef.current?.setScale(scale);
  }, [scale]);

  const startCamera = () => {
    setError(null);
    handlesRef.current?.startCamera();
  };
  const stopCamera = () => {
    handlesRef.current?.stopCamera();
  };

  const move = (x: number, y: number) => handlesRef.current?.move(x, y);
  const reset = () => {
    handlesRef.current?.resetObject();
    setScale(1);
  };

  const toggleFullscreen = async () => {
    if (!containerRef.current) return;
    try {
      if (!document.fullscreenElement) {
        await containerRef.current.requestFullscreen();
        setFullscreen(true);
      } else {
        await document.exitFullscreen();
        setFullscreen(false);
      }
    } catch {
      setError('Fullscreen unavailable in this browser.');
    }
  };

  const cameraOn = status === 'active';

  return (
    <div className="pt-24 px-4 sm:px-6 pb-16">
      <div className="mx-auto max-w-7xl">
        <header className="mb-6 fade-up">
          <span className="text-cyan-300 text-xs uppercase tracking-[0.25em]">Module 2</span>
          <h1 className="mt-2 font-display text-3xl sm:text-4xl font-bold text-white">Augmented Reality Mode</h1>
          <p className="mt-2 text-slate-300 max-w-2xl">
            Place virtual 3D objects into your live camera feed. Drag to rotate the object, pinch or use the
            slider to scale, and move it around the screen. Camera access is requested only when you start AR.
          </p>
        </header>

        <div className="grid lg:grid-cols-[1fr_320px] gap-5">
          {/* Camera + 3D canvas */}
          <div className={`relative glass rounded-3xl overflow-hidden ${fullscreen ? 'h-[80vh]' : 'h-[60vh]'}`}>
            <div ref={containerRef} className="absolute inset-0 bg-black">
              {/* Live camera video (object-cover) */}
              <video
                ref={videoRef}
                playsInline
                muted
                className="absolute inset-0 w-full h-full object-cover"
                style={{ visibility: cameraOn ? 'visible' : 'hidden' }}
              />
              {/* WebGL overlay (transparent) */}
              <canvas ref={canvasRef} className="absolute inset-0 w-full h-full touch-none" />

              {/* Idle / start overlay */}
              {!cameraOn && (
                <div className="absolute inset-0 grid place-items-center">
                  <div className="text-center max-w-sm px-6">
                    <div className="mx-auto w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500/30 to-indigo-500/20 grid place-items-center border border-white/10">
                      <Video className="w-7 h-7 text-cyan-200" />
                    </div>
                    <h3 className="mt-4 font-display text-xl text-white">Camera is off</h3>
                    <p className="mt-2 text-sm text-slate-300">
                      Start AR to request camera permission and overlay a 3D object on your real-world view.
                    </p>
                    <button onClick={startCamera} className="btn-primary mt-5" disabled={loading}>
                      <Video className="w-4 h-4" /> Start AR Camera
                    </button>
                    {arSupported === false && (
                      <p className="mt-3 text-xs text-amber-200/80">
                        Note: immersive WebXR AR is not detected on this device — using browser-based camera
                        overlay mode.
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* Top status bar */}
              <div className="absolute top-3 left-3 flex items-center gap-2">
                <span
                  className={`px-3 py-1.5 rounded-full text-xs flex items-center gap-1.5 ${
                    cameraOn ? 'bg-emerald-500/20 text-emerald-200 border border-emerald-400/40' : 'glass-strong text-slate-200'
                  }`}
                >
                  <span className={`w-2 h-2 rounded-full ${cameraOn ? 'bg-emerald-400 animate-pulse' : 'bg-slate-400'}`} />
                  {cameraOn ? 'Camera live' : status === 'requesting' ? 'Requesting…' : 'Camera off'}
                </span>
                {cameraOn && (
                  <button onClick={stopCamera} className="btn-ghost !py-1.5 !px-3 text-xs">
                    <CameraOff className="w-3.5 h-3.5" /> Stop
                  </button>
                )}
              </div>

              <div className="absolute top-3 right-3 flex gap-2">
                <button onClick={toggleFullscreen} className="btn-ghost !px-2.5 !py-2" title="Fullscreen">
                  {fullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                </button>
              </div>

              {/* Bottom controls when active */}
              {cameraOn && (
                <div className="absolute bottom-3 inset-x-3 flex flex-wrap items-center justify-between gap-2">
                  <span className="px-3 py-1.5 rounded-full text-xs glass-strong text-slate-200 flex items-center gap-1.5">
                    <ScanLine className="w-3.5 h-3.5" /> Drag object to rotate · Pinch to scale
                  </span>
                  <div className="flex gap-2">
                    <button onClick={() => move(0.3, 0)} className="btn-ghost !py-1.5 !px-3 text-xs" title="Move up">
                      <Move className="w-3.5 h-3.5 -rotate-90" /> Up
                    </button>
                    <button onClick={() => move(-0.3, 0)} className="btn-ghost !py-1.5 !px-3 text-xs">
                      Down
                    </button>
                    <button onClick={reset} className="btn-ghost !py-1.5 !px-3 text-xs">
                      <RotateCcw className="w-3.5 h-3.5" /> Reset
                    </button>
                  </div>
                </div>
              )}

              {loading && (
                <div className="absolute inset-0 grid place-items-center bg-ink-950/60">
                  <div className="text-center">
                    <div className="spinner mx-auto" />
                    <p className="mt-3 text-sm text-slate-300">Initializing AR scene…</p>
                  </div>
                </div>
              )}

              {error && (
                <div className="absolute bottom-3 right-3 max-w-sm glass-strong rounded-2xl p-4 border border-amber-400/30">
                  <div className="flex items-start gap-2">
                    <X className="w-4 h-4 text-amber-300 mt-0.5" />
                    <div>
                      <p className="text-amber-200 text-sm font-medium">Camera issue</p>
                      <p className="mt-1 text-xs text-slate-300">{error}</p>
                      <button onClick={() => setError(null)} className="mt-2 btn-ghost !py-1.5 !px-3 text-xs">
                        Dismiss
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Side panel */}
          <aside className="space-y-4">
            <div className="glass rounded-3xl p-5">
              <h3 className="font-display text-lg font-semibold text-white">Object to place</h3>
              <div className="mt-4 grid grid-cols-4 gap-2">
                {OBJECT_CATALOG.map((o) => {
                  const active = o.id === selectedId;
                  return (
                    <button
                      key={o.id}
                      onClick={() => setSelectedId(o.id)}
                      className={[
                        'aspect-square rounded-xl border text-[10px] font-medium transition-all grid place-items-center text-center px-1',
                        active
                          ? 'border-cyan-400/60 bg-cyan-400/15 text-white'
                          : 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/10',
                      ].join(' ')}
                    >
                      <span
                        className="w-6 h-6 rounded-md mb-1"
                        style={{ background: `#${o.accent.toString(16).padStart(6, '0')}` }}
                      />
                      <span className="leading-tight">{o.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="glass rounded-3xl p-5 space-y-4">
              <h3 className="font-display text-lg font-semibold text-white">Transform</h3>
              <label className="block">
                <div className="flex justify-between text-xs text-slate-300 mb-1">
                  <span>Scale</span>
                  <span>{scale.toFixed(2)}×</span>
                </div>
                <input
                  type="range"
                  min={0.2}
                  max={5}
                  step={0.05}
                  value={scale}
                  onChange={(e) => setScale(parseFloat(e.target.value))}
                  className="w-full"
                />
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button onClick={() => move(0, 0.3)} className="btn-ghost !py-2 text-xs">Up</button>
                <button onClick={() => move(0, -0.3)} className="btn-ghost !py-2 text-xs">Down</button>
                <button onClick={reset} className="btn-ghost !py-2 text-xs">
                  <RotateCcw className="w-3.5 h-3.5" /> Reset
                </button>
                <button onClick={() => move(-0.3, 0)} className="btn-ghost !py-2 text-xs">Left</button>
                <button onClick={() => move(0.3, 0)} className="btn-ghost !py-2 text-xs">Right</button>
                <button onClick={() => move(0, 0)} className="btn-ghost !py-2 text-xs opacity-50">Center</button>
              </div>
            </div>

            <div className="glass rounded-3xl p-5">
              <h3 className="font-display text-lg font-semibold text-white">How it works</h3>
              <ol className="mt-3 text-sm text-slate-300 space-y-2 list-decimal list-inside">
                <li>Click <b className="text-white">Start AR Camera</b> — your browser will ask permission.</li>
                <li>Pick a 3D object from the library.</li>
                <li>Drag on the scene to rotate, pinch / slider to scale.</li>
                <li>Use the move buttons to position it in the frame.</li>
              </ol>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
