import { Check, Minus, X } from 'lucide-react';
import type { ModuleId } from './Navbar';

interface CompareProps {
  onNavigate: (id: ModuleId) => void;
}

interface Row {
  feature: string;
  ar: string;
  vr: string;
}

interface AppRow {
  application: string;
  ar: string;
  vr: string;
}

const COMPARISON: Row[] = [
  {
    feature: 'Definition',
    ar: 'Overlays digital content on the real world.',
    vr: 'Replaces the real world with a fully synthetic environment.',
  },
  {
    feature: 'Environment',
    ar: 'Real world + virtual objects (mixed)',
    vr: 'Completely virtual 3D world',
  },
  {
    feature: 'User awareness',
    ar: 'User stays aware of physical surroundings',
    vr: 'User is immersed and isolated from reality',
  },
  {
    feature: 'Hardware required',
    ar: 'Smartphone camera or AR glasses (HoloLens)',
    vr: 'Head-mounted display (Meta Quest, HTC Vive)',
  },
  {
    feature: 'Input methods',
    ar: 'Touch, gestures, voice, marker tracking',
    vr: 'Hand controllers, gaze, hand tracking, keyboard',
  },
  {
    feature: 'Typical use',
    ar: 'Try-on, navigation, field service, education overlays',
    vr: 'Gaming, training simulations, virtual tours, design review',
  },
  {
    feature: 'Field of view',
    ar: 'Limited by device display / glasses',
    vr: 'Wide, fully surrounding the user',
  },
  {
    feature: 'Safety',
    ar: 'High — user can still see the real world',
    vr: 'Requires a clear play area; user is blind to surroundings',
  },
];

const APPLICATIONS: AppRow[] = [
  { application: 'Education', ar: 'Interactive textbooks, 3D models over pages', vr: 'Virtual labs, historical site visits' },
  { application: 'Healthcare', ar: 'Surgical overlays, vein visualization', vr: 'Surgery rehearsal, phobia treatment' },
  { application: 'Gaming', ar: 'Location-based games (Pokémon GO)', vr: 'Immersive 6DoF games' },
  { application: 'Retail', ar: 'Virtual try-on for products', vr: 'Virtual showrooms' },
  { application: 'Engineering', ar: 'On-site annotations of parts', vr: 'Design review of 3D CAD models' },
];

const ADVANTAGES_AR = [
  'Keeps user connected to the real world',
  'Often works on existing smartphones',
  'Enhances rather than replaces reality',
  'Useful for contextual, real-time info',
];

const ADVANTAGES_VR = [
  'Total immersion and presence',
  'Controlled, repeatable environments',
  'Powerful for training and simulation',
  'Eliminates real-world distractions',
];

export default function Compare({ onNavigate }: CompareProps) {
  return (
    <div className="pt-24 px-4 sm:px-6 pb-20">
      <div className="mx-auto max-w-7xl">
        <header className="mb-8 fade-up">
          <span className="text-cyan-300 text-xs uppercase tracking-[0.25em]">Module 5</span>
          <h1 className="mt-2 font-display text-3xl sm:text-4xl font-bold text-white">AR vs VR — Comparison</h1>
          <p className="mt-2 text-slate-300 max-w-2xl">
            Augmented Reality and Virtual Reality are related but fundamentally different technologies. The
            table below highlights how they compare across definition, hardware, use cases and safety.
          </p>
        </header>

        {/* Two big contrast cards */}
        <div className="grid md:grid-cols-2 gap-5 mb-10">
          <div className="glass rounded-3xl p-7 relative overflow-hidden">
            <div className="absolute -top-12 -right-12 w-48 h-48 rounded-full bg-cyan-500/20 blur-3xl" />
            <span className="text-cyan-300 text-xs uppercase tracking-[0.25em]">Augmented Reality</span>
            <h2 className="mt-3 font-display text-3xl font-bold text-white">Adds to reality</h2>
            <p className="mt-3 text-slate-300">Digital objects are layered on top of the real environment captured by a camera.</p>
            <ul className="mt-5 space-y-2">
              {ADVANTAGES_AR.map((a) => (
                <li key={a} className="flex items-start gap-2 text-sm text-slate-200">
                  <Check className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" /> {a}
                </li>
              ))}
            </ul>
            <button onClick={() => onNavigate('ar')} className="btn-primary mt-6">
              Try AR Mode
            </button>
          </div>

          <div className="glass rounded-3xl p-7 relative overflow-hidden">
            <div className="absolute -top-12 -right-12 w-48 h-48 rounded-full bg-violet-500/20 blur-3xl" />
            <span className="text-violet-300 text-xs uppercase tracking-[0.25em]">Virtual Reality</span>
            <h2 className="mt-3 font-display text-3xl font-bold text-white">Replaces reality</h2>
            <p className="mt-3 text-slate-300">The user is fully immersed inside a computer-generated 3D world.</p>
            <ul className="mt-5 space-y-2">
              {ADVANTAGES_VR.map((a) => (
                <li key={a} className="flex items-start gap-2 text-sm text-slate-200">
                  <Check className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" /> {a}
                </li>
              ))}
            </ul>
            <button onClick={() => onNavigate('vr')} className="btn-primary mt-6">
              Try VR Mode
            </button>
          </div>
        </div>

        {/* Comparison table */}
        <div className="glass rounded-3xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-white/5">
                  <th className="text-left font-display font-semibold text-white px-5 py-4">Feature</th>
                  <th className="text-left font-display font-semibold text-cyan-200 px-5 py-4">Augmented Reality</th>
                  <th className="text-left font-display font-semibold text-violet-200 px-5 py-4">Virtual Reality</th>
                </tr>
              </thead>
              <tbody>
                {COMPARISON.map((row, i) => (
                  <tr key={row.feature} className={i % 2 ? 'bg-white/[0.02]' : ''}>
                    <td className="px-5 py-4 font-medium text-white">{row.feature}</td>
                    <td className="px-5 py-4 text-slate-300">{row.ar}</td>
                    <td className="px-5 py-4 text-slate-300">{row.vr}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Applications comparison */}
        <h2 className="mt-12 font-display text-2xl font-semibold text-white">Applications side by side</h2>
        <div className="mt-4 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {APPLICATIONS.map((app) => (
            <div key={app.application} className="glass rounded-2xl p-5">
              <h3 className="font-display text-lg font-semibold text-white">{app.application}</h3>
              <div className="mt-3 space-y-3">
                <div className="flex items-start gap-2">
                  <span className="px-2 py-0.5 rounded text-[10px] bg-cyan-400/15 text-cyan-200 border border-cyan-400/30">AR</span>
                  <p className="text-sm text-slate-300">{app.ar}</p>
                </div>
                <div className="flex items-start gap-2">
                  <span className="px-2 py-0.5 rounded text-[10px] bg-violet-400/15 text-violet-200 border border-violet-400/30">VR</span>
                  <p className="text-sm text-slate-300">{app.vr}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Quick verdict */}
        <div className="mt-10 glass rounded-3xl p-6 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="font-display text-xl font-semibold text-white">Mixed Reality = AR + VR</h3>
            <p className="mt-1 text-sm text-slate-300 max-w-2xl">
              Modern devices blur the line — headsets like the Meta Quest 3 and Apple Vision Pro support both
              passthrough AR and immersive VR in one device.
            </p>
          </div>
          <div className="flex gap-2">
            <span className="px-3 py-1.5 rounded-full text-xs bg-white/5 border border-white/10 text-slate-200 flex items-center gap-1">
              <Check className="w-3 h-3 text-emerald-400" /> Complementary
            </span>
            <span className="px-3 py-1.5 rounded-full text-xs bg-white/5 border border-white/10 text-slate-200 flex items-center gap-1">
              <Minus className="w-3 h-3 text-amber-300" /> Different hardware
            </span>
            <span className="px-3 py-1.5 rounded-full text-xs bg-white/5 border border-white/10 text-slate-200 flex items-center gap-1">
              <X className="w-3 h-3 text-rose-400" /> Not interchangeable
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
