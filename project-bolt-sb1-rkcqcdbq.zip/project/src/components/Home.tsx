import { ArrowRight, Boxes, Camera, ChevronRight, Cpu, Glasses, Globe2 } from 'lucide-react';
import type { ModuleId } from './Navbar';

interface HomeProps {
  onNavigate: (id: ModuleId) => void;
}

const CARDS: {
  id: ModuleId;
  title: string;
  blurb: string;
  icon: typeof Boxes;
  gradient: string;
}[] = [
  {
    id: 'ar',
    title: 'AR Mode',
    blurb: 'Project virtual 3D objects into your real-world camera feed and transform them in place.',
    icon: Camera,
    gradient: 'from-cyan-500/30 to-blue-500/10',
  },
  {
    id: 'vr',
    title: 'VR Mode',
    blurb: 'Step into a virtual exhibition room with furniture, lighting and headset support.',
    icon: Glasses,
    gradient: 'from-violet-500/30 to-indigo-500/10',
  },
  {
    id: 'explorer',
    title: '3D Object Explorer',
    blurb: 'Inspect, rotate, zoom and scale individual 3D primitives and furniture models.',
    icon: Boxes,
    gradient: 'from-emerald-500/30 to-teal-500/10',
  },
];

const STATS = [
  { label: 'Interactive Modules', value: '6' },
  { label: '3D Objects', value: '8+' },
  { label: 'WebGL Powered', value: '100%' },
  { label: 'Hardware Free', value: 'Yes' },
];

export default function Home({ onNavigate }: HomeProps) {
  return (
    <div className="relative">
      {/* HERO */}
      <section className="relative pt-36 sm:pt-44 pb-20 px-4 sm:px-6">
        <div className="absolute inset-0 grid-overlay opacity-40 pointer-events-none" />
        <div className="mx-auto max-w-7xl">
          <div className="grid lg:grid-cols-2 gap-10 items-center">
            <div className="fade-up">
              <span className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium text-cyan-200 bg-cyan-500/10 border border-cyan-400/20">
                <Cpu className="w-3.5 h-3.5" /> WebXR · Three.js · MediaDevices
              </span>
              <h1 className="mt-5 font-display text-4xl sm:text-6xl font-bold leading-[1.05] tracking-tight">
                <span className="gradient-text">Augmented &amp; Virtual Reality</span>
                <br />
                <span className="text-white">Experience System</span>
              </h1>
              <p className="mt-5 text-lg text-slate-300 max-w-xl leading-relaxed">
                An interactive web platform demonstrating how Augmented Reality overlays digital content on the
                real world, and how Virtual Reality immerses you inside a fully synthetic 3D environment — all
                running in your browser, no headset required for the basics.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <button onClick={() => onNavigate('explorer')} className="btn-primary">
                  Start Exploring <ArrowRight className="w-4 h-4" />
                </button>
                <button onClick={() => onNavigate('compare')} className="btn-ghost">
                  What is AR vs VR? <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              <dl className="mt-12 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-2xl">
                {STATS.map((s) => (
                  <div key={s.label} className="glass rounded-2xl p-4">
                    <dt className="text-xs uppercase tracking-wide text-slate-400">{s.label}</dt>
                    <dd className="mt-1 font-display text-2xl font-semibold text-white">{s.value}</dd>
                  </div>
                ))}
              </dl>
            </div>

            {/* Animated hero visual */}
            <div className="relative h-[420px] fade-up" style={{ animationDelay: '0.15s' }}>
              <div className="absolute inset-0 rounded-3xl overflow-hidden glass">
                <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/30 via-transparent to-cyan-500/20" />
                <div className="absolute inset-0 grid-overlay opacity-60" />
                <div className="absolute left-8 top-10 float-slow">
                  <div className="w-28 h-28 rounded-2xl bg-gradient-to-br from-indigo-400 to-violet-500 shadow-glow rotate-12 opacity-90" />
                </div>
                <div className="absolute right-10 top-24 float-med">
                  <div className="w-20 h-20 rounded-full bg-gradient-to-br from-cyan-300 to-blue-500 shadow-glow" />
                </div>
                <div className="absolute left-1/2 bottom-16 -translate-x-1/2 float-slow" style={{ animationDelay: '1s' }}>
                  <div className="w-24 h-24 rounded-full border-2 border-cyan-300/40 grid place-items-center">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 shadow-glow" />
                  </div>
                </div>
                <div className="absolute bottom-6 left-1/2 -translate-x-1/2 text-center w-full">
                  <p className="text-xs text-slate-300 uppercase tracking-[0.3em]">Live WebGL Scene Preview</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* MODULE CARDS */}
      <section className="px-4 sm:px-6 pb-16">
        <div className="mx-auto max-w-7xl">
          <div className="flex items-end justify-between mb-6">
            <h2 className="font-display text-2xl sm:text-3xl font-semibold text-white">Choose your experience</h2>
            <span className="text-sm text-slate-400 hidden sm:block">Select a mode to begin</span>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {CARDS.map((card, i) => {
              const Icon = card.icon;
              return (
                <button
                  key={card.id}
                  onClick={() => onNavigate(card.id)}
                  className={`glass glow-border rounded-3xl p-6 text-left group relative overflow-hidden fade-up`}
                  style={{ animationDelay: `${i * 0.08}s` }}
                >
                  <div className={`absolute -right-10 -top-10 w-40 h-40 rounded-full bg-gradient-to-br ${card.gradient} blur-2xl opacity-70`} />
                  <div className="relative">
                    <span className="inline-grid place-items-center w-12 h-12 rounded-2xl bg-white/10 border border-white/15">
                      <Icon className="w-6 h-6 text-white" />
                    </span>
                    <h3 className="mt-5 font-display text-xl font-semibold text-white">{card.title}</h3>
                    <p className="mt-2 text-sm text-slate-300 leading-relaxed">{card.blurb}</p>
                    <span className="mt-5 inline-flex items-center gap-1.5 text-sm font-medium text-cyan-300 group-hover:gap-2.5 transition-all">
                      Enter module <ArrowRight className="w-4 h-4" />
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* INTRO TO AR & VR */}
      <section className="px-4 sm:px-6 pb-24">
        <div className="mx-auto max-w-7xl grid md:grid-cols-2 gap-6">
          <div className="glass rounded-3xl p-7">
            <span className="text-cyan-300 text-xs uppercase tracking-[0.25em]">Augmented Reality</span>
            <h3 className="mt-3 font-display text-2xl font-semibold text-white">Overlay digital on the real</h3>
            <p className="mt-3 text-slate-300 leading-relaxed">
              AR augments your live camera feed by placing computer-generated 3D objects into the real
              environment around you. The real world stays visible; virtual objects are composited on top and
              can be moved, rotated and scaled as if physically present.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              {['Camera feed', 'Object placement', 'Scale / rotate', 'Fallback 3D demo'].map((t) => (
                <span key={t} className="px-3 py-1 rounded-full text-xs bg-white/5 border border-white/10 text-slate-200">
                  {t}
                </span>
              ))}
            </div>
          </div>
          <div className="glass rounded-3xl p-7">
            <span className="text-violet-300 text-xs uppercase tracking-[0.25em]">Virtual Reality</span>
            <h3 className="mt-3 font-display text-2xl font-semibold text-white">Immerse in a synthetic world</h3>
            <p className="mt-3 text-slate-300 leading-relaxed">
              VR replaces your surroundings with a fully virtual 3D environment. This system builds a walkable
              exhibition room in Three.js — you can look around, move with the keyboard and, when a headset is
              connected, enter a true immersive WebXR session.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              {['3D room', 'Keyboard + mouse', 'WebXR headset', 'Furniture scene'].map((t) => (
                <span key={t} className="px-3 py-1 rounded-full text-xs bg-white/5 border border-white/10 text-slate-200">
                  {t}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      <footer className="px-6 pb-10 text-center text-xs text-slate-500">
        <div className="mx-auto max-w-7xl border-t border-white/5 pt-6 flex items-center justify-center gap-2">
          <Globe2 className="w-4 h-4" /> B.Tech CSE Mini-Project · Built with Three.js + WebXR
        </div>
      </footer>
    </div>
  );
}
