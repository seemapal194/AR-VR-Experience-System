import { useEffect, useRef, useState } from 'react';
import { Gamepad2, Glasses, Info, RotateCcw } from 'lucide-react';
import { createVRScene, type VRHandles } from '@/three/vrScene';
import { useWebXRSupport } from '@/lib/hooks';

export default function VRMode() {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const vrBtnHostRef = useRef<HTMLDivElement | null>(null);
  const handlesRef = useRef<VRHandles | null>(null);
  const { vrSupported } = useWebXRSupport();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [vrActive, setVRActive] = useState(false);
  const [showHelp, setShowHelp] = useState(true);

  useEffect(() => {
    if (!containerRef.current || !canvasRef.current || !vrBtnHostRef.current) return;
    let h: VRHandles | null = null;
    try {
      h = createVRScene({
        canvas: canvasRef.current,
        container: containerRef.current,
        vrButtonHost: vrBtnHostRef.current,
        onVRStateChange: setVRActive,
        onError: (m) => setError(m),
      });
      handlesRef.current = h;
      setLoading(false);
    } catch (e) {
      setError('WebGL initialization failed: ' + (e as Error).message);
      setLoading(false);
    }
    return () => {
      h?.dispose();
      handlesRef.current = null;
    };
  }, []);

  return (
    <div className="pt-24 px-4 sm:px-6 pb-16">
      <div className="mx-auto max-w-7xl">
        <header className="mb-6 fade-up flex flex-wrap items-end justify-between gap-4">
          <div>
            <span className="text-violet-300 text-xs uppercase tracking-[0.25em]">Module 3</span>
            <h1 className="mt-2 font-display text-3xl sm:text-4xl font-bold text-white">Virtual Reality Mode</h1>
            <p className="mt-2 text-slate-300 max-w-2xl">
              A fully built 3D exhibition room with furniture, lighting and decorative objects. Explore with
              mouse and keyboard — or enter a true immersive VR session if a headset is connected.
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button onClick={() => handlesRef.current?.resetView()} className="btn-ghost">
              <RotateCcw className="w-4 h-4" /> Reset view
            </button>
            <button onClick={() => setShowHelp((v) => !v)} className="btn-ghost">
              <Info className="w-4 h-4" /> {showHelp ? 'Hide' : 'Show'} controls
            </button>
          </div>
        </header>

        <div className="relative glass rounded-3xl overflow-hidden h-[72vh]">
          <div ref={containerRef} className="absolute inset-0">
            <canvas ref={canvasRef} className="w-full h-full block" />
          </div>

          {/* VR status pill */}
          <div className="absolute top-3 left-3 flex items-center gap-2">
            <span className="px-3 py-1.5 rounded-full text-xs glass-strong text-slate-200 flex items-center gap-1.5">
              <span
                className={`w-2 h-2 rounded-full ${vrActive ? 'bg-emerald-400' : 'bg-slate-400'} animate-pulse`}
              />
              {vrActive ? 'VR session active' : 'Desktop mode'}
            </span>
            {vrSupported !== null && (
              <span
                className={`px-3 py-1.5 rounded-full text-xs ${
                  vrSupported ? 'bg-emerald-400/15 text-emerald-200 border border-emerald-400/30' : 'glass-strong text-slate-300'
                }`}
              >
                {vrSupported ? 'Headset supported' : 'No headset — desktop fallback'}
              </span>
            )}
          </div>

          {/* Enter VR button (custom + native host) */}
          <div className="absolute top-3 right-3 flex items-center gap-2">
            <button
              onClick={() => handlesRef.current?.enterVR()}
              className="btn-primary text-sm"
              title="Request an immersive VR session"
            >
              <Glasses className="w-4 h-4" /> Enter VR
            </button>
            <div ref={vrBtnHostRef} className="hidden" aria-hidden />
          </div>

          {/* Help overlay */}
          {showHelp && !vrActive && (
            <div className="absolute bottom-3 left-3 right-3 sm:right-auto sm:w-[320px] glass-strong rounded-2xl p-4">
              <div className="flex items-center gap-2 text-white">
                <Gamepad2 className="w-4 h-4 text-cyan-300" />
                <h3 className="font-display font-semibold">Navigation</h3>
              </div>
              <ul className="mt-2 text-xs text-slate-300 space-y-1.5">
                <li><b className="text-white">Drag</b> — orbit the camera around the room</li>
                <li><b className="text-white">Scroll</b> — move closer / farther</li>
                <li><b className="text-white">W A S D</b> — walk through the room</li>
                <li><b className="text-white">Enter VR</b> — open immersive session if a headset is connected</li>
              </ul>
            </div>
          )}

          {loading && (
            <div className="absolute inset-0 grid place-items-center bg-ink-950/60">
              <div className="text-center">
                <div className="spinner mx-auto" />
                <p className="mt-3 text-sm text-slate-300">Building virtual room…</p>
              </div>
            </div>
          )}

          {error && (
            <div className="absolute bottom-3 right-3 max-w-sm glass-strong rounded-2xl p-4 border border-amber-400/30">
              <p className="text-amber-200 text-sm font-medium">Notice</p>
              <p className="mt-1 text-xs text-slate-300">{error}</p>
              <button onClick={() => setError(null)} className="mt-2 btn-ghost !py-1.5 !px-3 text-xs">
                Dismiss
              </button>
            </div>
          )}
        </div>

        <p className="mt-4 text-xs text-slate-400 max-w-3xl">
          Note: The 3D room is a real Three.js scene and is fully explorable on any WebGL-capable device.
          Immersive VR requires a WebXR-compatible headset (e.g. Meta Quest) and a WebXR-enabled browser such
          as Chrome or Firefox Reality. When no headset is present, the system gracefully falls back to the
          desktop experience above.
        </p>
      </div>
    </div>
  );
}
