import { useEffect, useRef, useState } from 'react';
import { Boxes, Maximize2, Minimize2, RotateCcw, Sparkles, ZoomIn, ZoomOut } from 'lucide-react';
import { OBJECT_CATALOG, cloneObjectById, type ObjectInfo } from '@/three/objects';
import { createObjectExplorer, type ExplorerHandles } from '@/three/explorer';

export default function ObjectExplorer() {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const handlesRef = useRef<ExplorerHandles | null>(null);
  const [selectedId, setSelectedId] = useState<string>(OBJECT_CATALOG[0].id);
  const [autoRotate, setAutoRotate] = useState(true);
  const [scale, setScale] = useState(1);
  const [rotSpeed, setRotSpeed] = useState(0.6);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [fullscreen, setFullscreen] = useState(false);

  const selectedInfo: ObjectInfo | undefined = OBJECT_CATALOG.find((o) => o.id === selectedId);

  useEffect(() => {
    if (!containerRef.current || !canvasRef.current) return;
    let h: ExplorerHandles | null = null;
    try {
      h = createObjectExplorer({
        canvas: canvasRef.current,
        container: containerRef.current,
        onSelect: (id) => {
          if (id) setSelectedId(id);
        },
        onError: (msg) => setError(msg),
      });
      handlesRef.current = h;
      (h as ExplorerHandles & { loadById: (id: string, b: (id: string) => any) => void }).loadById(
        OBJECT_CATALOG[0].id,
        cloneObjectById,
      );
      setLoading(false);
    } catch (e) {
      setError('WebGL could not be initialized on this device.');
      setLoading(false);
    }
    return () => {
      h?.dispose();
      handlesRef.current = null;
    };
  }, []);

  // Load object when selection changes
  useEffect(() => {
    const h = handlesRef.current as
      | (ExplorerHandles & { loadById?: (id: string, b: (id: string) => any) => void })
      | null;
    if (h && h.loadById) {
      h.loadById(selectedId, cloneObjectById);
      setScale(1);
    }
  }, [selectedId]);

  useEffect(() => {
    handlesRef.current?.setScale(scale);
  }, [scale]);

  useEffect(() => {
    handlesRef.current?.setRotationSpeed(rotSpeed);
  }, [rotSpeed]);

  useEffect(() => {
    handlesRef.current?.toggleAutoRotate(autoRotate);
  }, [autoRotate]);

  const zoom = (dir: 1 | -1) => {
    setScale((s) => Math.max(0.3, Math.min(3, +(s + dir * 0.2).toFixed(2))));
  };

  const reset = () => {
    handlesRef.current?.resetObject();
    setScale(1);
    setRotSpeed(0.6);
    setAutoRotate(true);
  };

  const toggleFullscreen = async () => {
    if (!containerRef.current) return;
    try {
      if (!document.fullscreenElement) {
        await containerRef.current.requestFullscreen();
        setFullscreen(true);
      } else {
        await document.exitFullscreen();
        setFullscreen(false);
      }
    } catch {
      setError('Fullscreen not available in this browser.');
    }
  };

  return (
    <div className="pt-24 px-4 sm:px-6 pb-16">
      <div className="mx-auto max-w-7xl">
        <header className="mb-6 fade-up">
          <span className="text-emerald-300 text-xs uppercase tracking-[0.25em]">Module 4</span>
          <h1 className="mt-2 font-display text-3xl sm:text-4xl font-bold text-white">3D Object Explorer</h1>
          <p className="mt-2 text-slate-300 max-w-2xl">
            Inspect realistic 3D primitives and furniture. Drag to orbit, scroll to zoom the camera, click an
            object to select it, and use the controls to scale and rotate it in real time.
          </p>
        </header>

        <div className="grid lg:grid-cols-[1fr_320px] gap-5">
          {/* Scene */}
          <div className={`relative glass rounded-3xl overflow-hidden ${fullscreen ? 'h-[80vh]' : 'h-[60vh]'}`}>
            <div ref={containerRef} className="absolute inset-0">
              <canvas ref={canvasRef} className="w-full h-full block" />
            </div>

            {/* Overlay controls */}
            <div className="absolute top-3 right-3 flex gap-2">
              <button onClick={() => zoom(1)} className="btn-ghost !px-2.5 !py-2" title="Zoom in object">
                <ZoomIn className="w-4 h-4" />
              </button>
              <button onClick={() => zoom(-1)} className="btn-ghost !px-2.5 !py-2" title="Zoom out object">
                <ZoomOut className="w-4 h-4" />
              </button>
              <button onClick={toggleFullscreen} className="btn-ghost !px-2.5 !py-2" title="Fullscreen">
                {fullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </button>
            </div>

            <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between">
              <span className="px-3 py-1.5 rounded-full text-xs glass-strong text-slate-200">
                Drag · Scroll to zoom camera · Click object to select
              </span>
              <button onClick={reset} className="btn-ghost !py-2 !px-3 text-xs">
                <RotateCcw className="w-4 h-4" /> Reset
              </button>
            </div>

            {loading && (
              <div className="absolute inset-0 grid place-items-center bg-ink-950/60">
                <div className="text-center">
                  <div className="spinner mx-auto" />
                  <p className="mt-3 text-sm text-slate-300">Initializing WebGL scene…</p>
                </div>
              </div>
            )}

            {error && (
              <div className="absolute inset-0 grid place-items-center bg-ink-950/80 p-6">
                <div className="glass-strong rounded-2xl p-6 max-w-md text-center">
                  <p className="text-rose-300 font-medium">Unable to start 3D scene</p>
                  <p className="mt-2 text-sm text-slate-300">{error}</p>
                </div>
              </div>
            )}
          </div>

          {/* Side panel */}
          <aside className="space-y-4">
            <div className="glass rounded-3xl p-5">
              <h3 className="font-display text-lg font-semibold text-white flex items-center gap-2">
                <Boxes className="w-5 h-5 text-emerald-300" /> Object Library
              </h3>
              <div className="mt-4 grid grid-cols-4 gap-2">
                {OBJECT_CATALOG.map((o) => {
                  const active = o.id === selectedId;
                  return (
                    <button
                      key={o.id}
                      onClick={() => setSelectedId(o.id)}
                      className={[
                        'aspect-square rounded-xl border text-[10px] font-medium transition-all grid place-items-center text-center px-1',
                        active
                          ? 'border-emerald-400/60 bg-emerald-400/15 text-white'
                          : 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/10',
                      ].join(' ')}
                      style={{ color: active ? '#fff' : undefined }}
                    >
                      <span
                        className="w-6 h-6 rounded-md mb-1"
                        style={{ background: `#${o.accent.toString(16).padStart(6, '0')}` }}
                      />
                      <span className="leading-tight">{o.name}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {selectedInfo && (
              <div className="glass rounded-3xl p-5">
                <div className="flex items-center gap-2">
                  <span
                    className="w-3 h-3 rounded-full"
                    style={{ background: `#${selectedInfo.accent.toString(16).padStart(6, '0')}` }}
                  />
                  <h3 className="font-display text-lg font-semibold text-white">{selectedInfo.name}</h3>
                </div>
                <p className="mt-2 text-sm text-slate-300 leading-relaxed">{selectedInfo.description}</p>
                <p className="mt-3 text-xs text-slate-400 uppercase tracking-wide">
                  Category: {selectedInfo.category}
                </p>
              </div>
            )}

            <div className="glass rounded-3xl p-5 space-y-4">
              <h3 className="font-display text-lg font-semibold text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-cyan-300" /> Transform
              </h3>

              <label className="block">
                <div className="flex justify-between text-xs text-slate-300 mb-1">
                  <span>Scale</span>
                  <span>{scale.toFixed(2)}×</span>
                </div>
                <input
                  type="range"
                  min={0.3}
                  max={3}
                  step={0.05}
                  value={scale}
                  onChange={(e) => setScale(parseFloat(e.target.value))}
                  className="w-full"
                />
              </label>

              <label className="block">
                <div className="flex justify-between text-xs text-slate-300 mb-1">
                  <span>Rotation speed</span>
                  <span>{rotSpeed.toFixed(2)}</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={3}
                  step={0.05}
                  value={rotSpeed}
                  onChange={(e) => setRotSpeed(parseFloat(e.target.value))}
                  className="w-full"
                />
              </label>

              <button
                onClick={() => setAutoRotate((v) => !v)}
                className={autoRotate ? 'btn-primary w-full' : 'btn-ghost w-full'}
              >
                {autoRotate ? 'Auto-rotate: ON' : 'Auto-rotate: OFF'}
              </button>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
