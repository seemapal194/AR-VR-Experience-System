import { ArrowLeftRight, Boxes, Camera, Compass, Glasses, Home } from 'lucide-react';

export type ModuleId = 'home' | 'explorer' | 'vr' | 'ar' | 'compare' | 'info';

interface NavItem {
  id: ModuleId;
  label: string;
  icon: typeof Home;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'home', label: 'Home', icon: Home },
  { id: 'explorer', label: '3D Explorer', icon: Boxes },
  { id: 'vr', label: 'VR Mode', icon: Glasses },
  { id: 'ar', label: 'AR Mode', icon: Camera },
  { id: 'compare', label: 'AR vs VR', icon: ArrowLeftRight },
  { id: 'info', label: 'Applications', icon: Compass },
];

interface NavbarProps {
  active: ModuleId;
  onNavigate: (id: ModuleId) => void;
}

export default function Navbar({ active, onNavigate }: NavbarProps) {
  return (
    <header className="fixed top-0 inset-x-0 z-50">
      <nav className="mx-auto max-w-7xl px-4 sm:px-6 mt-3">
        <div className="glass-strong rounded-2xl px-4 sm:px-6 py-3 flex items-center justify-between">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2.5 group"
            aria-label="Go to home"
          >
            <span className="relative grid place-items-center w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-cyan-400 shadow-glow">
              <Compass className="w-5 h-5 text-white" />
            </span>
            <span className="font-display font-semibold text-white tracking-tight hidden sm:block">
              AR&nbsp;&amp;&nbsp;VR<span className="text-brand-cyan"> System</span>
            </span>
          </button>

          <ul className="hidden md:flex items-center gap-1">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = active === item.id;
              return (
                <li key={item.id}>
                  <button
                    onClick={() => onNavigate(item.id)}
                    className={[
                      'flex items-center gap-2 px-3.5 py-2 rounded-xl text-sm font-medium transition-all',
                      isActive
                        ? 'bg-white/10 text-white shadow-inner'
                        : 'text-slate-300 hover:text-white hover:bg-white/5',
                    ].join(' ')}
                  >
                    <Icon className="w-4 h-4" />
                    {item.label}
                  </button>
                </li>
              );
            })}
          </ul>

          <button
            onClick={() => onNavigate('vr')}
            className="btn-primary text-sm hidden sm:inline-flex"
          >
            <Glasses className="w-4 h-4" /> Launch VR
          </button>

          {/* Mobile select */}
          <select
            value={active}
            onChange={(e) => onNavigate(e.target.value as ModuleId)}
            className="md:hidden bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm text-white"
            aria-label="Navigate"
          >
            {NAV_ITEMS.map((item) => (
              <option key={item.id} value={item.id} className="bg-ink-900">
                {item.label}
              </option>
            ))}
          </select>
        </div>
      </nav>
    </header>
  );
}
