import { BookOpen, Building2, Gamepad2, HeartPulse, Plane, Wrench } from 'lucide-react';
import type { ModuleId } from './Navbar';

interface InfoProps {
  onNavigate: (id: ModuleId) => void;
}

interface AppCard {
  icon: typeof BookOpen;
  title: string;
  color: string;
  ar: string;
  vr: string;
  examples: string[];
}

const APPS: AppCard[] = [
  {
    icon: BookOpen,
    title: 'Education',
    color: 'from-indigo-500/30 to-blue-500/10',
    ar: 'AR brings textbooks to life — 3D models of molecules, planets or anatomy appear on top of pages when scanned with a phone.',
    vr: 'VR lets students take virtual field trips: walk through the Roman Colosseum, dive into a coral reef, or perform a chemistry experiment in a safe virtual lab.',
    examples: ['Google Expeditions', 'AR anatomy apps', 'Virtual chemistry labs'],
  },
  {
    icon: HeartPulse,
    title: 'Healthcare',
    color: 'from-rose-500/30 to-pink-500/10',
    ar: 'Surgeons use AR overlays to see MRI data projected onto a patient during operations; nurses use AR to locate veins for injections.',
    vr: 'VR is used for surgical training rehearsal, pain management, exposure therapy for phobias and PTSD, and rehabilitation.',
    examples: ['AccuVein vein finder', 'Osso VR surgery training', 'Exposure therapy'],
  },
  {
    icon: Gamepad2,
    title: 'Gaming & Entertainment',
    color: 'from-violet-500/30 to-fuchsia-500/10',
    ar: 'AR games blend digital characters with the real world — Pokémon GO is the iconic example. AR filters power social media.',
    vr: 'VR delivers fully immersive 6-degrees-of-freedom games, concerts and cinematic experiences that surround the player.',
    examples: ['Pokémon GO', 'Beat Saber', 'VR concerts'],
  },
  {
    icon: Plane,
    title: 'Tourism',
    color: 'from-cyan-500/30 to-teal-500/10',
    ar: 'AR overlays historical reconstructions and facts on monuments as tourists point their phones at them.',
    vr: 'VR offers virtual tours of museums, hotels and destinations before booking — explore the Louvre from home.',
    examples: ['Google Arts & Culture', 'Virtual hotel walkthroughs', 'AR city guides'],
  },
  {
    icon: Building2,
    title: 'Engineering & Architecture',
    color: 'from-amber-500/30 to-orange-500/10',
    ar: 'AR superimposes CAD models on construction sites so engineers can compare plans with the built structure.',
    vr: 'VR lets architects and clients walk through unbuilt buildings at 1:1 scale to review design before construction.',
    examples: ['BIM XR review', 'Architectural walkthroughs', 'Clash detection'],
  },
  {
    icon: Wrench,
    title: 'Industrial Training',
    color: 'from-emerald-500/30 to-green-500/10',
    ar: 'AR glasses guide factory workers with hands-free step-by-step instructions overlaid on the machinery.',
    vr: 'VR simulates hazardous or expensive scenarios — oil rigs, aviation, firefighting — without real-world risk.',
    examples: ['Boeing wiring AR', 'VR aviation training', 'Hazard simulators'],
  },
];

const FUTURE_TRENDS = [
  'Cheaper, lighter standalone headsets (Meta Quest 3, Apple Vision Pro)',
  'Mixed Reality blending AR + VR in a single device',
  'WebXR making immersive content run in any browser',
  'AI-generated 3D content filling virtual worlds',
  'Haptic suits and gloves for realistic touch feedback',
  'Social VR metaverse platforms for work and play',
];

export default function Info({ onNavigate }: InfoProps) {
  return (
    <div className="pt-24 px-4 sm:px-6 pb-20">
      <div className="mx-auto max-w-7xl">
        <header className="mb-8 fade-up">
          <span className="text-emerald-300 text-xs uppercase tracking-[0.25em]">Module 6</span>
          <h1 className="mt-2 font-display text-3xl sm:text-4xl font-bold text-white">Information &amp; Applications</h1>
          <p className="mt-2 text-slate-300 max-w-2xl">
            AR and VR are reshaping how we learn, work, shop and play. Explore the major fields where these
            technologies are already in production today.
          </p>
        </header>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {APPS.map((app, i) => {
            const Icon = app.icon;
            return (
              <article
                key={app.title}
                className="glass glow-border rounded-3xl p-6 relative overflow-hidden fade-up"
                style={{ animationDelay: `${i * 0.06}s` }}
              >
                <div className={`absolute -top-10 -right-10 w-40 h-40 rounded-full bg-gradient-to-br ${app.color} blur-2xl opacity-70`} />
                <div className="relative">
                  <span className="inline-grid place-items-center w-11 h-11 rounded-2xl bg-white/10 border border-white/15">
                    <Icon className="w-5.5 h-5.5 text-white" />
                  </span>
                  <h3 className="mt-4 font-display text-xl font-semibold text-white">{app.title}</h3>
                  <div className="mt-3 space-y-3 text-sm">
                    <p className="text-slate-300">
                      <span className="text-cyan-300 text-xs font-semibold uppercase tracking-wide">AR · </span>
                      {app.ar}
                    </p>
                    <p className="text-slate-300">
                      <span className="text-violet-300 text-xs font-semibold uppercase tracking-wide">VR · </span>
                      {app.vr}
                    </p>
                  </div>
                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {app.examples.map((ex) => (
                      <span key={ex} className="px-2.5 py-1 rounded-full text-[11px] bg-white/5 border border-white/10 text-slate-200">
                        {ex}
                      </span>
                    ))}
                  </div>
                </div>
              </article>
            );
          })}
        </div>

        {/* Future trends */}
        <section className="mt-12 grid lg:grid-cols-[1fr_1.2fr] gap-6">
          <div className="glass rounded-3xl p-7">
            <span className="text-cyan-300 text-xs uppercase tracking-[0.25em]">Outlook</span>
            <h2 className="mt-3 font-display text-2xl font-semibold text-white">Future trends</h2>
            <ul className="mt-4 space-y-3">
              {FUTURE_TRENDS.map((t) => (
                <li key={t} className="flex items-start gap-2 text-sm text-slate-200">
                  <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-cyan-400 shrink-0" />
                  {t}
                </li>
              ))}
            </ul>
          </div>

          <div className="glass rounded-3xl p-7 flex flex-col">
            <h2 className="font-display text-2xl font-semibold text-white">Experience it yourself</h2>
            <p className="mt-3 text-slate-300">
              The best way to understand AR and VR is to try them. This system lets you overlay objects on your
              camera feed and walk through a virtual room — all from a browser.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <button onClick={() => onNavigate('ar')} className="btn-primary">Launch AR Mode</button>
              <button onClick={() => onNavigate('vr')} className="btn-ghost">Launch VR Mode</button>
              <button onClick={() => onNavigate('explorer')} className="btn-ghost">3D Explorer</button>
            </div>
            <div className="mt-auto pt-6 text-xs text-slate-400">
              Built as a B.Tech CSE mini-project using Three.js, WebXR, the MediaDevices API and WebGL.
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
